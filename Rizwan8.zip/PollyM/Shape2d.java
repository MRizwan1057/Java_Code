//  Shape2d.java

public abstract class Shape2d
{
	
	public abstract double getArea(); 
	public abstract double getPeremeter();
}  // end abstract class Shape2d