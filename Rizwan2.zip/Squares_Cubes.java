// display numbers ,squares & cubes

public class Squares_Cubes
{
	public static void main(String[] args)
	{
		System.out.print("Numbers \t\t\t Squares \t\t\t Cubes");
		System.out.print("\n");
		int a =0;
		int b =1;
		int c =2;
		int d =3;
		int e =4;
		int f =5;
		int g =6;
		int h =7;
		int i =8;
		int j =9;
		int k =10;
		System.out.printf("%d %S %d %s %d %n",a, "				", a*a, "				", a*a*a);
		System.out.printf("%d %S %d %s %d %n",b, "				", b*b, "				", b*b*b);
		System.out.printf("%d %S %d %s %d %n",c, "				", c*c, "				", c*c*c);
		System.out.printf("%d %S %d %s %d %n",d, "				", d*d, "				", d*d*d);
		System.out.printf("%d %S %d %s %d %n",e, "				", e*e, "				", e*e*e);
		System.out.printf("%d %S %d %s %d %n",f, "				", f*f, "				", f*f*f);
		System.out.printf("%d %S %d %s %d %n",g, "				", g*g, "				", g*g*g);
		System.out.printf("%d %S %d %s %d %n",h, "				", h*h, "				", h*h*h);
		System.out.printf("%d %S %d %s %d %n",i, "				", i*i, "				", i*i*i);
		System.out.printf("%d %S %d %s %d %n",j, "				", j*j, "				", j*j*j);
		System.out.printf("%d %S %d %s %d %n",k, "				", k*k, "				", k*k*k);
	
	
 }
 }
