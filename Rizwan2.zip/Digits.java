// spacing between digits of a number

import java.util.Scanner;
public class Digits
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int x;
		
		System.out.print("enter a five-digit number: ");
		x = input.nextInt();
		
		System.out.printf("%d%n",x);
	}
}