// DataTest.java
public class DataTest
{
	public static void main(String[] args)
	{
	
		Data myData = new Data(17,07,1999);
	
	// Employee emp2 = new Employee("Muhammad", "Usman", (double)60000.0);
	
	
			System.out.printf(" *** My Date of Birth is !!*** : %s %s %s %s %s %n", myData.getdate(),"/", myData.getmonth(), "/",myData.getyear());
			
			
	}
}