// Data.java
public class Data
{
	public int date;
	public int month;
	public int year;
	
	
	// initialize constructor with parameter name
	public Data (int date, int month, int year)
	{
		this.date = date;
		this.month = month;
		this.year = year;
	}
	
	
	// set name method
	public void setdate(int date)
	{
		this.date = date;
	}
	
	// method to get name
	public int getdate()
	{
	return date;
	}
	
	// set name method
	public void setmonth(int month)
	{
		this.month = month;
	}
	
	// method to get name
	public int getmonth()
	{
	return month;
	}
	// set name method
	public void setyear(int year)
	{
		this.year = year;
	}
	
	// method to get name
	public int getyear()
	{
	return year;

	}

}
